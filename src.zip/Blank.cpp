#include "Blank.h"
Blank::Blank(){}
Blank::~Blank(){}
