#include "ShipComponent.h"

ShipComponent::ShipComponent()
{
}

ShipComponent::~ShipComponent()
{
}
