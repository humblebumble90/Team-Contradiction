#pragma once
#ifndef __BLANK__
#define __BLANK__
#endif
#include "ShipComponent.h"
class Blank : public ShipComponent
{
public:
	Blank();
	~Blank();
};